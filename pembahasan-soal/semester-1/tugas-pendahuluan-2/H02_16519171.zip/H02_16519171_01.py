# NIM/Nama : 16519171/Mgs. Tabrani
# Tanggal : 8 Oktober 2019
# Deskripsi : Program_Angka_1_sampai_N
#Menampilkan_Angka_1_sampai_N_dalam_satu_baris

#Kamus
#N, i : int

#Algoritma
N = int(input("Masukkan N: "))
for i in range(1,N+1):
    print(i, end=" ")

    



