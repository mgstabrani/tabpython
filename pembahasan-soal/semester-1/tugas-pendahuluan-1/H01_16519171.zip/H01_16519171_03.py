'''
Nama : Mgs. Tabrani
NIM : 16519171

Program Menentukan Sifat Bilangan : Positif/Negatif/Nol

Kamus
> X : int
*X harus bilangan bulat
'''

X = int(input("Masukkan nilai X : ")) #Memasukkan nilai X

if (X > 0): #Jika X > 0, maka lakukan di bawah
	if (X%2 == 0):
		print("X adalah bilangan positif genap") #Jika X habis dibagi 2, maka X adalah bilangan bulat positif genap
	else:
		print("X adalah bilangan positif ganjil") #Jika X tidak habis dibagi 2, maka X adalah bilangan bulat positif ganjil

elif (X < 0): #Jika X < 0, maka lakukan di bawah
	if (X%2 == 0):
		print("X adalah bilangan negatif genap") #Jika X habis dibagi 2, maka X adalah bilangan bulat negatif genap
	else:
		print("X adalah bilangan negatif ganjil") #Jika X tidak habis dibagi 2, maka X adalah bilangan bulat negatif ganjil

else: #X sama dengan 0, maka lakukan di bawah
	print("X adalah bilangan nol")

