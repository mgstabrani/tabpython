'''
Nama : Mgs. Tabrani
NIM : 16519171

ProgramTulisanHelloWorld!
MenampilkanTulisanHelloWorld!
'''

print("Hello, World!") #Cetak tulisan "Hello, World!"
