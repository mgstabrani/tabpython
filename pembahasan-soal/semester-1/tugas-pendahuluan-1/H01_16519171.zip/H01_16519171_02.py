'''
Nama : Mgs. Tabrani
NIM : 16519171

ProgramKalkulatorSederhana

Kamus
> A, B : float
> C = string
'''

A = float(input("Masukkan bilangan pertama : ")) #Memasukkan bilangan pertama

B = float(input("Masukkan bilangan kedua : ")) #Memasukkan bilangan kedua

C = str(input("Masukkan operasi : ")) #Memasukkan operasi hitung

if (C == "+"): 
	print("Hasilnya = " + str(A + B)) #Jika operasinya "+", maka hasilnya A ditambah B

elif (C == "-"):
	print("Hasilnya = " + str(A - B)) #Jika operasinya "-", maka hasilnya A dikurangi B

elif (C == "x"):
	print("Hasilnya = " + str(A * B)) #Jika operasinya "x", maka hasilnya A dikali B

elif (C == ":"):
	print("Hasilnya = " + str(A / B)) #Jika operasinya ":", maka hasilnya A dibagi B

elif (C == "%"):
	print("Hasilnya = " + str(A%B)) #Jika operasinya "%", maka hasilnya A mod B

else:
	print("ERROR") #Tanda selain yang di atas akan error